﻿using System;
using System.Windows.Forms;

namespace OOPFractal
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        //  static void Main()
        //    {

        //
        //         Application.EnableVisualStyles();
        //         Application.SetCompatibleTextRenderingDefault(false);
        //     Application.Run(new FormProject());

        // }
        static void Main(string[] args)
        {          
            //Triangle_new c = new Triangle_new();

            Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                 Application.Run(new FormProject());
           


        }


    }
}
