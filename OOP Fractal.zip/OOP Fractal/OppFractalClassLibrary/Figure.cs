﻿using System;
using System.Drawing;

namespace OppFractalClassLibrary
{
    //базов абстрактен клас Figure
    public abstract class Figure
    {

        public int FigureId { get; set; }
        public string FigureName { get; set; }
        public string FigureType { get; set; }
        public string FigureColor { get; set; }
        public double FigureArea { get; set; }
        public double FigurePerimetar { get; set; }
        public bool Solid { get; set; }
        public int Order { get; set; }
        public string Color { get; set; }

        private int x;
        private int y;
       


        public Figure()
        {

        }
        public Figure(int newx, int newy)
        {
            setX(newx);
            setY(newy);
      
        }



        //  x & y 
        public int getX() { return x; }
        public int getY() { return y; }
        public void setX(int newx) { x = newx; }
        public void setY(int newy) { y = newy; }
        
        

        //преместване на  x & y
        public void moveTo(int newx, int newy)
        {
            setX(newx);
            setY(newy);
        }
        public void rMoveTo(int deltax, int deltay)
        {
            moveTo(deltax + getX(), deltay + getY());
        }

        // абстракти програми -за лице и периметър на фигури
        //предефинират се в следващия от иерархията клас RegPolygon
      
        public abstract double Area();
        public abstract int Perimetar();

        public abstract void DrawFigures( Graphics _graph, string colorone);
    
    }
    } 
